using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

/// <summary>Creates the clean starter scene and repeatable build targets.</summary>
public static class BuildBootstrap
{
    private const string ScenePath = "Assets/Scenes/NeonReels.unity";

    [MenuItem("Neon Reels/Create Starter Scene")]
    public static void CreateStarterScene()
    {
        Directory.CreateDirectory("Assets/Scenes");
        var scene = UnityEditor.SceneManagement.EditorSceneManager.NewScene(
            UnityEditor.SceneManagement.NewSceneSetup.EmptyScene,
            UnityEditor.SceneManagement.NewSceneMode.Single);

        var cameraObject = new GameObject("Main Camera");
        cameraObject.tag = "MainCamera";
        cameraObject.transform.position = new Vector3(0f, 0f, -10f);
        var camera = cameraObject.AddComponent<Camera>();
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color(0.025f, 0.035f, 0.09f);
        camera.orthographic = true;
        cameraObject.AddComponent<AudioListener>();

        var game = new GameObject("Neon Reels Game");
        game.AddComponent<NeonReelsGame>();

        UnityEditor.SceneManagement.EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        Debug.Log("Neon Reels starter scene created at " + ScenePath);
    }

    [MenuItem("Neon Reels/Build WebGL")]
    public static void BuildWebGL()
    {
        CreateStarterScene();
        PlayerSettings.companyName = "Neon Reels Arcade";
        PlayerSettings.productName = "Neon Reels";
        PlayerSettings.bundleVersion = "1.0.0";
        PlayerSettings.defaultScreenWidth = 1440;
        PlayerSettings.defaultScreenHeight = 900;
        PlayerSettings.runInBackground = true;
        PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Disabled;
        PlayerSettings.WebGL.exceptionSupport = WebGLExceptionSupport.None;
        Directory.CreateDirectory("Build/WebGL");

        var options = new BuildPlayerOptions
        {
            scenes = new[] { ScenePath },
            locationPathName = "Build/WebGL",
            target = BuildTarget.WebGL,
            options = BuildOptions.None
        };
        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result != BuildResult.Succeeded)
        {
            Debug.LogError("WebGL build failed: " + report.summary.result);
            return;
        }
        Debug.Log("WebGL build succeeded: " + report.summary.totalSize + " bytes");
    }
}
