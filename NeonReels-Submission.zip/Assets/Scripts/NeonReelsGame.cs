using System;
using UnityEngine;

/// <summary>
/// A dependency-free, responsive slot machine built with Unity's immediate UI.
/// The artwork is drawn from simple shapes and type so the project runs without
/// external packages or fonts in both the Editor and a WebGL build.
/// </summary>
public sealed class NeonReelsGame : MonoBehaviour
{
    private enum ReelSymbol
    {
        Cherry,
        Seven,
        Star,
        Diamond,
        Heart,
        Bar
    }

    private sealed class Reel
    {
        public ReelSymbol Current;
        public ReelSymbol Result;
        public bool IsSpinning;
        public float StopAt;
        public float NextTickAt;
    }

    private const int StartingCredits = 1000;
    private const int MinimumBet = 10;
    private const int MaximumBet = 100;
    private const int BetStep = 10;
    private const float DesignWidth = 1440f;
    private const float DesignHeight = 900f;

    private readonly Reel[] reels = { new Reel(), new Reel(), new Reel() };
    private readonly string[] symbolNames = { "CHERRY", "SEVEN", "STAR", "DIAMOND", "HEART", "BAR" };
    private readonly string[] symbolMarks = { "●", "7", "★", "◆", "♥", "BAR" };
    private readonly Color[] symbolColors =
    {
        new Color(1f, 0.31f, 0.45f),
        new Color(1f, 0.77f, 0.31f),
        new Color(0.55f, 0.86f, 1f),
        new Color(0.71f, 0.55f, 1f),
        new Color(1f, 0.43f, 0.71f),
        new Color(0.38f, 0.91f, 0.75f)
    };

    private Texture2D whiteTexture;
    private GUIStyle labelStyle;
    private GUIStyle buttonStyle;
    private GUIStyle smallButtonStyle;
    private int credits = StartingCredits;
    private int bet = 20;
    private int lastWin;
    private bool isSpinning;
    private bool lastWasWin;
    private float nextPulse;
    private float pulse;
    private string message = "PLACE YOUR BET AND HIT SPIN";
    private string detail = "TRIPLE MATCH PAYS — EVERY SYMBOL HAS ITS OWN MULTIPLIER";

    private void Awake()
    {
        Application.targetFrameRate = 60;
        whiteTexture = new Texture2D(1, 1, TextureFormat.RGBA32, false)
        {
            name = "Neon Reels UI Pixel",
            hideFlags = HideFlags.HideAndDontSave
        };
        whiteTexture.SetPixel(0, 0, Color.white);
        whiteTexture.Apply();

        // Start with a visually balanced set; the first spin uses fresh RNG.
        for (int i = 0; i < reels.Length; i++)
        {
            reels[i].Current = (ReelSymbol)(i % Enum.GetValues(typeof(ReelSymbol)).Length);
        }
    }

    private void Update()
    {
        float now = Time.unscaledTime;
        if (now >= nextPulse)
        {
            pulse = Mathf.PingPong(now * 1.4f, 1f);
            nextPulse = now + 0.035f;
        }

        if (!isSpinning)
        {
            return;
        }

        bool anyReelSpinning = false;
        for (int i = 0; i < reels.Length; i++)
        {
            Reel reel = reels[i];
            if (!reel.IsSpinning)
            {
                continue;
            }

            anyReelSpinning = true;
            if (now >= reel.NextTickAt)
            {
                reel.Current = NextDifferentSymbol(reel.Current);
                float tickSpeed = Mathf.Lerp(0.055f, 0.12f, Mathf.InverseLerp(reel.StopAt - 0.7f, reel.StopAt, now));
                reel.NextTickAt = now + tickSpeed;
            }

            if (now >= reel.StopAt)
            {
                reel.Current = reel.Result;
                reel.IsSpinning = false;
            }
        }

        if (!anyReelSpinning)
        {
            // All three reels have stopped. The payout is settled only now.
            isSpinning = false;
            SettleSpin();
        }
    }

    private void OnGUI()
    {
        if (whiteTexture == null)
        {
            return;
        }

        float scale = Mathf.Min(Screen.width / DesignWidth, Screen.height / DesignHeight);
        float offsetX = (Screen.width - DesignWidth * scale) * 0.5f;
        float offsetY = (Screen.height - DesignHeight * scale) * 0.5f;
        Matrix4x4 previousMatrix = GUI.matrix;
        Color previousColor = GUI.color;
        GUI.matrix = Matrix4x4.TRS(new Vector3(offsetX, offsetY, 0f), Quaternion.identity, new Vector3(scale, scale, 1f));

        DrawBackground();
        DrawHeader();
        DrawCabinet();
        DrawBottomBar();

        GUI.matrix = previousMatrix;
        GUI.color = previousColor;

        if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Space)
        {
            Event.current.Use();
            StartSpin();
        }
    }

    private void DrawBackground()
    {
        DrawRect(0, 0, DesignWidth, DesignHeight, new Color(0.025f, 0.035f, 0.09f));
        DrawRect(0, 0, DesignWidth, 128, new Color(0.035f, 0.045f, 0.12f));
        DrawRect(0, 126, DesignWidth, 2, new Color(0.32f, 0.3f, 0.62f, 0.55f));

        // Fine decorative lines keep the stage lively without relying on image assets.
        for (int i = 0; i < 18; i++)
        {
            float y = 178 + i * 36;
            DrawRect(0, y, 96 + (i % 4) * 30, 1, new Color(0.28f, 0.46f, 0.73f, 0.10f));
            DrawRect(DesignWidth - 130 - (i % 4) * 30, y + 15, 130 + (i % 3) * 24, 1, new Color(0.75f, 0.34f, 0.70f, 0.11f));
        }
        DrawRect(0, 838, DesignWidth, 62, new Color(0.035f, 0.045f, 0.12f));
    }

    private void DrawHeader()
    {
        DrawRect(88, 43, 40, 40, new Color(0.92f, 0.36f, 0.77f));
        DrawLabel("N", new Rect(88, 40, 40, 42), 24, Color.white, FontStyle.Bold, TextAnchor.MiddleCenter);
        DrawLabel("NEON REELS", new Rect(143, 39, 260, 46), 25, Color.white, FontStyle.Bold, TextAnchor.MiddleLeft);
        DrawLabel("ARCADE   /   01", new Rect(1050, 45, 300, 34), 15, new Color(0.61f, 0.69f, 0.9f), FontStyle.Bold, TextAnchor.MiddleRight);
        DrawDot(1368, 62, 8, new Color(0.36f, 0.93f, 0.75f));
        DrawLabel("LIVE", new Rect(1380, 44, 48, 35), 12, new Color(0.56f, 0.95f, 0.81f), FontStyle.Bold, TextAnchor.MiddleLeft);
    }

    private void DrawCabinet()
    {
        DrawLabel("LUCK IS A LIGHT SHOW", new Rect(0, 155, DesignWidth, 48), 31, Color.white, FontStyle.Bold, TextAnchor.MiddleCenter);
        DrawLabel("THREE REELS. ONE PERFECT MATCH.", new Rect(0, 199, DesignWidth, 30), 14, new Color(0.61f, 0.68f, 0.87f), FontStyle.Normal, TextAnchor.MiddleCenter);

        // Shadow and cabinet body.
        DrawRect(219, 258, 1002, 515, new Color(0.01f, 0.015f, 0.045f, 0.72f));
        DrawRect(210, 248, 1020, 515, new Color(0.12f, 0.1f, 0.25f));
        DrawRect(222, 260, 996, 491, new Color(0.055f, 0.07f, 0.17f));
        DrawRect(222, 260, 996, 4, new Color(0.93f, 0.38f, 0.78f, 0.88f));
        DrawRect(222, 747, 996, 4, new Color(0.41f, 0.74f, 1f, 0.84f));
        DrawLabel("NEON JACKPOT", new Rect(280, 275, 430, 38), 17, new Color(0.81f, 0.85f, 1f), FontStyle.Bold, TextAnchor.MiddleLeft);
        DrawLabel("TRIPLE SYMBOL PAYOUTS", new Rect(710, 275, 432, 38), 13, new Color(0.52f, 0.61f, 0.8f), FontStyle.Bold, TextAnchor.MiddleRight);

        DrawRect(273, 334, 894, 259, new Color(0.018f, 0.025f, 0.07f));
        DrawRect(273, 334, 894, 3, new Color(0.26f, 0.38f, 0.63f, 0.66f));
        DrawRect(273, 590, 894, 3, new Color(0.26f, 0.38f, 0.63f, 0.66f));

        const float reelWidth = 258f;
        const float reelHeight = 207f;
        const float reelGap = 23f;
        float firstX = 304f;
        for (int i = 0; i < reels.Length; i++)
        {
            DrawReel(firstX + i * (reelWidth + reelGap), 357, reelWidth, reelHeight, i);
        }

        DrawLabel("CREDITS", new Rect(300, 625, 240, 25), 12, new Color(0.59f, 0.67f, 0.87f), FontStyle.Bold, TextAnchor.MiddleLeft);
        DrawLabel(credits.ToString("N0"), new Rect(300, 647, 240, 51), 34, Color.white, FontStyle.Bold, TextAnchor.MiddleLeft);
        DrawLabel("LAST WIN", new Rect(544, 625, 190, 25), 12, new Color(0.59f, 0.67f, 0.87f), FontStyle.Bold, TextAnchor.MiddleLeft);
        DrawLabel(lastWin > 0 ? "+" + lastWin.ToString("N0") : "—", new Rect(544, 647, 190, 51), 29, lastWin > 0 ? new Color(0.48f, 0.96f, 0.79f) : new Color(0.65f, 0.7f, 0.83f), FontStyle.Bold, TextAnchor.MiddleLeft);
        DrawLabel("BET", new Rect(762, 625, 132, 25), 12, new Color(0.59f, 0.67f, 0.87f), FontStyle.Bold, TextAnchor.MiddleCenter);

        bool canAdjustBet = !isSpinning;
        if (DrawButton("−", new Rect(766, 660, 42, 42), smallButtonStyle, canAdjustBet))
        {
            bet = Mathf.Max(MinimumBet, bet - BetStep);
        }
        DrawLabel(bet.ToString(), new Rect(813, 658, 74, 45), 24, Color.white, FontStyle.Bold, TextAnchor.MiddleCenter);
        if (DrawButton("+", new Rect(893, 660, 42, 42), smallButtonStyle, canAdjustBet))
        {
            bet = Mathf.Min(MaximumBet, bet + BetStep);
        }

        string spinLabel = isSpinning ? "SPINNING…" : credits < bet ? "NO CREDITS" : "SPIN  ›";
        Color spinColor = isSpinning || credits < bet ? new Color(0.25f, 0.28f, 0.39f) : new Color(0.91f, 0.36f + pulse * 0.08f, 0.72f);
        DrawRect(958, 650, 211, 61, new Color(spinColor.r * 0.55f, spinColor.g * 0.42f, spinColor.b * 0.72f, 0.85f));
        GUI.backgroundColor = spinColor;
        if (DrawButton(spinLabel, new Rect(964, 655, 199, 51), buttonStyle, !isSpinning && credits >= bet))
        {
            StartSpin();
        }
        GUI.backgroundColor = Color.white;

        DrawLabel(message, new Rect(280, 715, 880, 27), 15, lastWasWin ? new Color(0.53f, 0.98f, 0.78f) : new Color(0.83f, 0.86f, 0.96f), FontStyle.Bold, TextAnchor.MiddleCenter);
        DrawLabel(detail, new Rect(280, 738, 880, 18), 10, new Color(0.54f, 0.62f, 0.8f), FontStyle.Normal, TextAnchor.MiddleCenter);
    }

    private void DrawReel(float x, float y, float width, float height, int reelIndex)
    {
        Reel reel = reels[reelIndex];
        DrawRect(x, y, width, height, new Color(0.12f, 0.15f, 0.28f));
        DrawRect(x + 4, y + 4, width - 8, height - 8, new Color(0.91f, 0.94f, 1f));
        DrawRect(x + 8, y + 8, width - 16, height - 16, new Color(0.99f, 0.99f, 1f));

        Color tint = symbolColors[(int)reel.Current];
        float bounce = reel.IsSpinning ? Mathf.Sin(Time.unscaledTime * 23f + reelIndex) * 4f : 0f;
        DrawRect(x + 20, y + 22 + bounce, width - 40, 4, new Color(tint.r, tint.g, tint.b, 0.56f));
        DrawSymbolMark(reel.Current, new Rect(x + 20, y + 43 + bounce, width - 40, 91));
        DrawLabel(symbolNames[(int)reel.Current], new Rect(x + 10, y + 143, width - 20, 30), 14, new Color(0.16f, 0.2f, 0.34f), FontStyle.Bold, TextAnchor.MiddleCenter);
        DrawRect(x + 20, y + height - 28, width - 40, 3, new Color(tint.r, tint.g, tint.b, 0.56f));

        DrawDot(x + 14, y + 14, 4, tint);
        DrawDot(x + width - 14, y + 14, 4, tint);
        DrawDot(x + 14, y + height - 14, 4, tint);
        DrawDot(x + width - 14, y + height - 14, 4, tint);
    }

    private void DrawSymbolMark(ReelSymbol symbol, Rect rect)
    {
        Color color = symbolColors[(int)symbol];
        DrawLabel(symbolMarks[(int)symbol], rect, symbol == ReelSymbol.Bar ? 37 : 75, color, FontStyle.Bold, TextAnchor.MiddleCenter);
        if (symbol == ReelSymbol.Cherry)
        {
            DrawRect(rect.center.x - 4, rect.y + 22, 4, 32, new Color(0.23f, 0.62f, 0.39f));
            DrawDot(rect.center.x - 25, rect.y + 50, 23, color);
            DrawDot(rect.center.x + 25, rect.y + 52, 23, new Color(0.92f, 0.22f, 0.39f));
        }
        else if (symbol == ReelSymbol.Bar)
        {
            DrawRect(rect.x + 45, rect.y + 31, rect.width - 90, 39, new Color(0.06f, 0.13f, 0.25f));
            DrawLabel("BAR", new Rect(rect.x + 47, rect.y + 29, rect.width - 94, 42), 25, Color.white, FontStyle.Bold, TextAnchor.MiddleCenter);
        }
    }

    private void DrawBottomBar()
    {
        DrawRect(88, 860, 1264, 1, new Color(0.35f, 0.42f, 0.66f, 0.42f));
        DrawLabel("TRIPLE 7  ×12     •     TRIPLE DIAMOND  ×8     •     ANY OTHER TRIPLE  ×5", new Rect(95, 866, 870, 24), 12, new Color(0.68f, 0.73f, 0.89f), FontStyle.Bold, TextAnchor.MiddleLeft);
        DrawLabel("SPACE  /  SPIN", new Rect(1080, 866, 260, 24), 12, new Color(0.68f, 0.73f, 0.89f), FontStyle.Bold, TextAnchor.MiddleRight);
    }

    private void StartSpin()
    {
        if (isSpinning || credits < bet)
        {
            return;
        }

        credits -= bet;
        lastWin = 0;
        lastWasWin = false;
        message = "GOOD LUCK — WATCH THE REELS";
        detail = "RANDOM OUTCOMES · INDEPENDENT REELS · NO NEAR-MISS CONTROL";

        float now = Time.unscaledTime;
        for (int i = 0; i < reels.Length; i++)
        {
            Reel reel = reels[i];
            reel.Result = (ReelSymbol)UnityEngine.Random.Range(0, Enum.GetValues(typeof(ReelSymbol)).Length);
            reel.IsSpinning = true;
            reel.StopAt = now + 1.25f + i * 0.48f;
            reel.NextTickAt = now;
        }
        isSpinning = true;
    }

    private void SettleSpin()
    {
        ReelSymbol first = reels[0].Result;
        if (first != reels[1].Result || first != reels[2].Result)
        {
            lastWasWin = false;
            message = "NO MATCH — TRY ANOTHER SPIN";
            detail = "YOUR BET WAS " + bet + " CREDITS · TRIPLE SYMBOLS WIN";
            return;
        }

        int multiplier = first == ReelSymbol.Seven ? 12 : first == ReelSymbol.Diamond ? 8 : 5;
        lastWin = bet * multiplier;
        credits += lastWin;
        lastWasWin = true;
        message = "JACKPOT — TRIPLE " + symbolNames[(int)first] + "!  +" + lastWin.ToString("N0") + " CREDITS";
        detail = "YOUR " + bet + " CREDIT BET PAID " + multiplier + "×";
    }

    private ReelSymbol NextDifferentSymbol(ReelSymbol current)
    {
        int next = UnityEngine.Random.Range(0, Enum.GetValues(typeof(ReelSymbol)).Length - 1);
        return (ReelSymbol)(next >= (int)current ? next + 1 : next);
    }

    private void DrawDot(float x, float y, float diameter, Color color)
    {
        Color previous = GUI.color;
        GUI.color = color;
        GUI.DrawTexture(new Rect(x - diameter * 0.5f, y - diameter * 0.5f, diameter, diameter), whiteTexture);
        GUI.color = previous;
    }

    private void DrawRect(float x, float y, float width, float height, Color color)
    {
        Color previous = GUI.color;
        GUI.color = color;
        GUI.DrawTexture(new Rect(x, y, width, height), whiteTexture);
        GUI.color = previous;
    }

    private void DrawLabel(string text, Rect rect, int fontSize, Color color, FontStyle style, TextAnchor alignment)
    {
        if (labelStyle == null)
        {
            labelStyle = new GUIStyle(GUI.skin.label);
        }

        labelStyle.fontSize = fontSize;
        labelStyle.fontStyle = style;
        labelStyle.alignment = alignment;
        labelStyle.normal.textColor = color;
        labelStyle.wordWrap = false;
        GUI.Label(rect, text, labelStyle);
    }

    private bool DrawButton(string text, Rect rect, GUIStyle style, bool enabled)
    {
        if (buttonStyle == null)
        {
            buttonStyle = new GUIStyle(GUI.skin.button)
            {
                fontSize = 20,
                fontStyle = FontStyle.Bold
            };
            smallButtonStyle = new GUIStyle(buttonStyle) { fontSize = 22 };
            buttonStyle.normal.textColor = Color.white;
            buttonStyle.hover.textColor = Color.white;
            buttonStyle.active.textColor = Color.white;
            smallButtonStyle.normal.textColor = Color.white;
            smallButtonStyle.hover.textColor = Color.white;
            smallButtonStyle.active.textColor = Color.white;
        }
        style = style == null ? buttonStyle : style;

        if (!enabled)
        {
            GUI.enabled = false;
        }
        bool clicked = GUI.Button(rect, text, style);
        GUI.enabled = true;
        return clicked;
    }

    private void OnDestroy()
    {
        if (whiteTexture != null)
        {
            Destroy(whiteTexture);
        }
    }
}
